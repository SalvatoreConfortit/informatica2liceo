function areacirc(r){
return Math.pow (r,2) * Math.PI}
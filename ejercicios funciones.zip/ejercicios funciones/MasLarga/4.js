var x = 'caldo';
var empty = '';
console.log('caldo is ' + x.length + ' code units long');
console.log('The empty string has a length of ' + empty.length);

